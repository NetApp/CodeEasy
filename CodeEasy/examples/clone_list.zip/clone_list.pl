#============================================================#
#                                                            #
#                                                            #
# vollist.pl                                                 #
#                                                            #
# Sample code to list the volumes available in the cluster.  #
#                                                            #
# This sample code is supported from Cluster-Mode            #
# Data ONTAP 8.1 onwards.                                    #
#                                                            #
# Copyright 2011 NetApp, Inc. All rights reserved.           #
# Specifications subject to change without notice.           #
#                                                            #
#============================================================#

use lib "../../../../../lib/perl/NetApp";
use NaServer;
use NaElement;
use strict;

my $args = $#ARGV + 1;
my ($server, $ipaddr, $user, $passwd);

sub list_clones {
    my ($in, $out, $tag);

    $tag = "";
    
    while (defined($tag)) {
        $in = NaElement->new("volume-clone-get-iter");
        if ($tag ne "") {
            $in->child_add_string("tag", $tag);
        }
        
        my $out = $server->invoke_elem($in);
        if ($out->results_status() eq "failed") {
            print($out->results_reason() ."\n");
            exit(-1);
        }
        
        print("----------------------------------------------------\n");
        print("XML structure:\n\n");
        print($out->sprintf());
        print("----------------------------------------------------\n");
        
        $tag = $out->child_get_string("next-tag");
        
        if ($out->child_get_int("num-records") == 0) {
            continue;
        }
        
        my @volCloneList = $out->child_get("attributes-list")->children_get();
        my $volCloneInfo;
        
        foreach $volCloneInfo (@volCloneList) {
            my ($aggregate, $dsid, $msid, $volume, $volumeType, $vserver);
            $aggregate = $volCloneInfo->child_get_string("aggregate");
            $dsid = $volCloneInfo->child_get_string("dsid");
            $msid = $volCloneInfo->child_get_string("msid");
            $volume = $volCloneInfo->child_get_string("volume");
            $volumeType = $volCloneInfo->child_get_string("volume-type");
            $vserver = $volCloneInfo->child_get_string("vserver");
            
            print("----------------------------------------------------\n");
            print("Vserver                 : $vserver \n");
            print("Aggregate               : $aggregate \n");
            print("Volume                  : $volume \n");
            print("Volume Type             : $volumeType \n");
            print("Dsid                    : $dsid \n");
            print("Msid                    : $msid \n");
            print("----------------------------------------------------\n");
        }
    }
}

sub main() {

    if ($args < 3) {
        print "clone_list.pl <ip> <uesr> <password>\n";
        exit(-1);
    }
    $ipaddr = $ARGV[0];
    $user = $ARGV[1];
    $passwd = $ARGV[2];

    $server = NaServer->new($ipaddr, 1, 15);
    $server->set_style("LOGIN");
    $server->set_admin_user($user, $passwd);
    $server->set_transport_type("HTTP");
    list_clones();
}

main();
